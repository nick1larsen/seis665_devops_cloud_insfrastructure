#!/bin/bash
sudo cp /var/www/html/wordpress/wp-config.php wp-config.php
sudo cp /var/log/httpd/access_log access_log
